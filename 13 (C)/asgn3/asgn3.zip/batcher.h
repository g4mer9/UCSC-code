#pragma once

#include "stats.h"

void batcher_sort(Stats *stats, uint32_t *A, uint32_t n);
