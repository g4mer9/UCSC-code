#pragma once

#include "stats.h"

void shell_sort(Stats *stats, uint32_t *arr, uint32_t length);
