#ifndef __CODE_H__
#define __CODE_H__

#include <inttypes.h>

#define STOP_CODE 0
#define EMPTY_CODE 1
#define START_CODE 2
#define MAX_CODE UINT16_MAX

#endif
