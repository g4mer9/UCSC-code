#include "word.h"
#include <stdio.h>